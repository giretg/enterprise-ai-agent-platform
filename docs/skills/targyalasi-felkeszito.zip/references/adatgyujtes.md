# CRM- és webes adatgyűjtés

## Az API használata

Az elérhető OpenAPI-szerződésből dolgozz. Ha az alkalmazás a műveleteket kész eszközként adja, az `operationId`, a leírás és a sémák alapján válaszd ki őket. Ha közvetlen HTTP áll rendelkezésre, a szerződés `servers` bejegyzését vagy a környezet `CRM_BASE_URL` értékét használd; a hitelesítést a futtatókörnyezet vagy a felhasználó biztosítja. Ne kérj kulcsot, ha a csatlakoztatott eszköz már hitelesít.

Minden adatlekérés csak olvasás. A válaszburok payloadja jellemzően a `data`; a `meta.nextCursor` jelzi a további oldalt. Tartsd tiszteletben a rate limitet, és 429 esetén a válasz utasítása szerint próbáld újra. Csonkolt vagy félbehagyott eredményből ne közölj teljes összeget.

## Minimális lekérdezési terv

Az alábbi műveletnevek útjelzők, nem az OpenAPI helyettesítői.

1. **Partner feloldása:** `listAccounts` név szerinti kereséssel, ha nincs stabil CRM-azonosító. Rögzítsd az `account.id`, `name/company_name`, Mozaik-kód és adószám mezőket az azonosság ellenőrzéséhez.
2. **Account 360:** `getAccount360`, először `view=summary`. Ez adja a törzsadatot, health mezőket, felelőst, kapcsolattartókat, telephelyeket, partner-postaládákat, aktivitásokat, interakciókat, teendőket, háttérkondíciót és havi forgalmat. `view=full` csak akkor kell, ha a szükséges részletet kisebb célzott olvasási művelet nem adja vissza. A **nyitott ajánlatok** és **nyitott lehetőségek** CRM-funkciók jelenleg nem működnek — ne kérdezd le őket, és ne írj róluk a briefben.
3. **Rendelések és termékmix:** az adott `accountId`-re, az utolsó 12 lezárt naptári hónapra kérd a rendeléseket tételsorokkal (`listOrders`, `include=lineItems`) vagy a lapos rendeléstételeket (`listOrderLines`). A tárgyhavi részidőszakot külön kérd le. Lapozz végig. A jelentéshez számold össze legalább a nettó értéket, rendelések számát, mennyiséget a mező mértékegységével, havi értékeket, top termékeket/brandeket, sajátmárkát és az Ostoros-részesedést, amennyiben a termékadat ezt megbízhatóan jelöli.
4. **Összehasonlító riport:** aggregáláshoz előbb nézd meg a riport preseteket és metaadatokat (`getReportsPresets`, `getReportsMetadata`), majd használd a `postReportsQuery` műveletet. Partnerforgalomhoz a `partner-turnover` preset vagy az `account.id` szűrős, havi időszemcsés lekérdezés a kiindulás. Az aktuális szerződésben elfogadott filtert/dimenziót/mértéket használd. Az előző, azonos hosszúságú 12 hónapot is kérd le, ha a CRM nem ad kész összevetést.
5. **Kommunikáció:** az Account 360 legutóbbi elemei mellett kérd az `activities` adatot `accountId` és 12 havi dátumhatárral. Az `interactions` adatot `refEntity=Account`, `refId=<accountId>` szűréssel lapozd addig, amíg elérted az időablak elejét. Az e-mail, hívás, meeting, jegyzet és feladat külön típus maradjon; időrendben vond össze őket, az ismétlődést kiszűrve.
6. **Teendők és riasztások:** az Account 360 mellett ellenőrizd a partnerhez tartozó teendőket és értékesítési riasztásokat, ha az OpenAPI támogatja az `accountId` szerinti szűrést. Nyitott ajánlatokról és nyitott lehetőségekről ne írj — ezek a CRM-ben egyelőre nem működnek.
7. **Dokumentumok:** a dokumentumlistából csak a tárgyaláshoz releváns metaadatot és engedélyezett kinyert szöveget használd. Érzékenységi szintet ne emelj automatikusan.

## Adatleltár

Minden sor kerüljön be a briefbe vagy az adathiányok közé.

| Terület | Ellenőrizendő adatok |
|---|---|
| Azonosítás | cégnév, CRM-id, Mozaik-kód/alias, adószám |
| Törzsadat | típus, státusz, régió, szegmens, csatorna, csoport, leírás |
| Felelősség | account owner, fő kapcsolattartók és szerepük |
| Elérhetőség | tárgyaláshoz szükséges üzleti telefon/e-mail, telephelyek |
| Egészség | health score, indok, next best action, utolsó rendelés |
| Kereskedelmi érték | gördülő 12 havi forgalom, partnerpotenciál, háttérkondíció |
| Trend | havi forgalom, rendelésszám, mennyiség, előző 12 hónaphoz változás |
| Mix | top termék/brand, Ostoros-termékek, sajátmárka, új/eltűnt tételek |
| Kapcsolat | utolsó kommunikációk, döntések, ígéretek, nyitott kérdések |
| Teendők és riasztások | nyitott teendők, értékesítési riasztások |
| Dokumentumok | releváns szerződés/dokumentum és státusza |
| Web | tevékenység, tulajdonos, méretjelzők, boros kapcsolat, akciók, események |

## Webes kutatási terv

Azonosítsd a céget cégnév, domain, adószám és cím alapján. Azonos nevű más vállalkozás híreit zárd ki.

Forrásprioritás:

1. a cég hivatalos weboldala, hírei, webshopja és akciós újságai;
2. hivatalos cégnyilvántartás, éves beszámoló, hatósági vagy tőzsdei közlés;
3. a cég ellenőrzött közösségi oldala és hivatalos sajtóközleménye;
4. megbízható kereskedelmi/szakmai média;
5. aggregátor csak nyomként, közvetlen forrás hiányában jól jelölve.

Keresési témák az elmúlt 12 hónapra:

- `"<cégnév>" bor`, `wine`, `pezsgő`, `alkohol`, `ital`;
- `"<cégnév>" akció`, `akciós újság`, `katalógus`, `szórólap`, `borfesztivál`;
- `site:<hivatalos-domain> bor` és a cég saját keresője/archívuma;
- `"<cégnév>" Ostoros`, `Ostorosbor`, illetve releváns Ostoros márka- és terméknevek;
- tulajdonosváltás, üzletnyitás/-zárás, beszerzési vagy kategóriavezető-váltás, pénzügyi eredmény, felvásárlás, hálózatbővülés, fenntarthatósági vagy szabályozási ügy.

Keresési találati kivonatból ne állíts tényt: nyisd meg az oldalt. Akció esetén rögzítsd a promóció időpontját, terméket/borvidéket/márkát, árat vagy kedvezményt, csatornát és az Ostoros számára várható hatást. Fizetőfal vagy eltűnt oldal esetén ezt írd le, és csak a látható rész erejéig állíts.
