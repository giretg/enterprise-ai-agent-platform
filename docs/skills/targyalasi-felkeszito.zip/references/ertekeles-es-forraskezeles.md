# Értékelés és forráskezelés

## Bizonyítékszintek

Használd következetesen a következő címkéket:

- **Tény:** közvetlenül szerepel CRM-adatban vagy megnyitott nyilvános forrásban.
- **Számított:** forrásadatokból reprodukálható művelettel készült; a képletet röviden add meg a forrásjegyzetben.
- **Következtetés:** több tény üzleti értelmezése; fogalmazz valószínűséggel, ne bizonyossággal.
- **Javaslat:** a tárgyaláson ajánlott lépés vagy kérdés.

Egy webes állítást legalább egy közvetlen forrás támasszon alá. Tulajdonosi adatnál hivatalos vagy elsődleges forrást használj; ha ez nincs, nevezd meg az alacsonyabb bizonyosságot. Egymásnak ellentmondó adatokat ne olvassz össze: mindkettőt és a dátumukat mutasd meg.

## Partnerpotenciál

Adj `Magas`, `Közepes` vagy `Alacsony` minősítést, és rögtön utána 2–3 bizonyítékot. Az értékelés szempontjai:

- jelenlegi gördülő 12 havi forgalom és helyezés/részesedés a partnerállományban;
- trend és rendelési gyakoriság;
- üzlethálózat, vendéglátóhely, disztribúciós elérés vagy más nyilvános méretjelző;
- bor-kategória aktivitása és az Ostoros-portfólió illeszkedése;
- termékrés és bővítési esemény;
- fizetési, egészségi, koncentrációs vagy kapcsolati kockázat.

A minősítés relatív az Ostorosbor üzletéhez. Ha nincs partner-összehasonlítás vagy megbízható méretadat, írd: `Nem minősíthető megbízhatóan`, majd add meg, mely adat döntené el.

## Trend összefoglalása

Az 5–8 mondatos szóbeli összefoglaló mondja ki:

1. a 12 havi nettó forgalmat, rendelésszámot és az előző azonos időszakhoz mért változást;
2. a trend irányát és azt, hogy tartós-e vagy néhány hónap/rendelés okozza;
3. a szezonalitást, csúcsot, mélypontot és az esetleges rendelési szünetet;
4. a termék-/brandmix fontos elmozdulását, külön az Ostoros és sajátmárka szerepét;
5. a kommunikációval vagy nyilvános eseménnyel alátámasztott magyarázatot;
6. a tárgyalási következményt.

Az azonos hosszúságú előző időszak változása: `(aktuális − előző) / előző × 100`. Nulla előző értéknél ne képezz százalékot; írd, hogy új forgalom. Részleges hónapot teljes hónappal ne hasonlíts össze jelölés nélkül.

## Tárgyalási iránytű

A brief végkövetkeztetése legyen használható az asztalnál:

- egy mondatos fő cél;
- legfeljebb három, fontossági sorrendbe tett téma;
- három konkrét, nyitott kérdés az ügyfélnek;
- legfeljebb három lehetőség és három kockázat, mindegyik mögött bizonyíték;
- egy ajánlott minimum eredmény és egy ideális eredmény;
- kerülendő állítások: bizonytalan vagy elavult információk, amelyeket előbb validálni kell.

## Forrásjegyzék

A HTML-ben a tény után legyen rövid jelölés (`[CRM-1]`, `[WEB-2]`). A végén minden jelöléshez add meg:

- CRM-nél: művelet/végpont, account-id, lekért időszak, lekérés napja;
- webnél: oldal címe, kiadó, közzétételi dátum (ha van), elérés napja és közvetlen kattintható URL;
- számítottnál: bemenő forrásjelölések és rövid képlet.

A forrásjegyzék után külön `Adathiányok és bizonytalanságok` blokk következzen. Ez sorolja fel a sikertelen lekérést, hiányzó mezőt, nem igazolható tulajdonost, csonka webarchívumot és minden olyan feltételezést, amely módosíthatja a tárgyalási ajánlást.
