---
name: targyalasi-felkeszito
description: Ügyféltárgyalási felkészítő készítése az Ostorosbor CRM Connector API-jának ügyfél-, kommunikációs és rendelési adataiból, valamint friss nyilvános webes forrásokból, egyetlen nyomtatható HTML-ben. Használd, ha a felhasználó meeting briefet, tárgyalási anyagot vagy ügyfélfelkészítőt kér egy partnerhez.
allowed-tools: 
---
# Tárgyalási felkészítő

Készíts döntéstámogató, belső használatú briefet egy ügyféllel való tárgyaláshoz. A kész eredmény egy önálló, statikus, magyar nyelvű HTML-fájl; a tárgyaló fél öt perc alatt értse meg belőle, kivel ül le, mi változott és mit érdemes elérnie.

## Bemenet

A partner neve vagy CRM-azonosítója kötelező. A tárgyalás dátuma, résztvevői és célja opcionális; hiányuk ne állítsa meg az adatgyűjtést. Azonos nevű vagy nem egyértelmű találatnál mutasd meg röviden a jelölteket, és kérj választást. Partnerazonosságot ne találj ki.

## Munkamenet

1. Olvasd el a [CRM- és webes adatgyűjtés](references/adatgyujtes.md) leírását. Az aktuálisan elérhető OpenAPI-dokumentáció a végpontok, paraméterek és mezők forrása; azt kövesd az itt szereplő példák helyett, ha eltérés van. A partner akkor azonosított, ha egyetlen CRM `account.id` és a hozzá tartozó cégnév rögzítve van.
2. Gyűjtsd össze a partner Account 360 adatait, az utolsó kommunikációkat, teendőket, riasztásokat és az elmúlt 12 hónap teljes rendelési/forgalmi képét. A lapozott adatforrásokat addig járd be, amíg a 12 hónapos időablak teljes vagy a forrás véget ér. A gyűjtés akkor kész, ha az [adatleltár](references/adatgyujtes.md#adatleltár) minden sora adatot vagy kifejezett hiányjelzést kapott.
3. Keress friss nyilvános információt a cégről és az elmúlt 12 hónap boros aktivitásáról. Tulajdonost csak ellenőrizhető forrásból nevezz meg. Akciót csak dátummal és közvetlen forrásoldallal állíts. A kutatás akkor kész, ha a cégazonosságot ellenőrizted, a releváns találatokat megnyitottad, és minden webes tényhez van közvetlen URL.
4. Olvasd el az [értékelési és forráskezelési szabályokat](references/ertekeles-es-forraskezeles.md), majd vond le a tárgyalás szempontjából hasznos következtetéseket. A számolt érték legyen visszavezethető a forrásmezőkre; a következtetés ne jelenjen meg tényként.
5. Másold az [HTML-sablont](assets/targyalasi-felkeszito-sablon.html), és cseréld ki az összes `{{...}}` helyőrzőt. A blokkokba kész HTML markup kerüljön. A minta: [minta-targyalasi-felkeszito.html](assets/minta-targyalasi-felkeszito.html).
6. Mentsd `targyalasi-felkeszito-<slug>-<YYYY-MM-DD>.html` néven, ahol a <slug> kisbetűs, ékezet nélküli rövid név (pl. spar, vino-trade; max 40 karakter, csak [a-z0-9-]). Teljes jogi cégnevet, szóközt, pontot és ékezetes karaktert a fájlnévbe TILOS tenni. A válaszodban a `file_write` által visszaadott `path` mezőt szó szerint, backtickben idézd — a fájlnevet sose rekonstruáld fejből. Mentés után ellenőrizd fájl-előnézetben és nyomtatási nézetben.

## Tartalmi sorrend

Az első képernyőn legyen pontosan öt, egyenként egy mondatos vezetői sor:

1. ki a cég és mivel foglalkozik;
2. kik a tulajdonosai, vagy hogy ez nyilvános forrásból nem volt megbízhatóan igazolható;
3. mekkora és milyen jellegű partner az Ostorosbor számára;
4. mi változott az elmúlt 12 hónapban;
5. mi legyen a tárgyalás fő célja.

Ezután a sablon sorrendjében jelenjen meg:

- tárgyalási iránytű: cél, ajánlott álláspont, három prioritás, három megválaszolandó kérdés;
- ügyfélkép és Account 360 mezők;
- 12 havi forgalmi és rendelési trend szóbeli összefoglalója, havi adatsor és termékmix;
- utolsó kommunikációk, vállalások, teendők és riasztások;
- webes cégkép, borhoz való kapcsolat, boros akciók és releváns vállalati események;
- az Ostorosbor-kapcsolatra gyakorolt hatás, lehetőségek, kockázatok és konkrét beszélgetési pontok;
- forrásjegyzék és adathiányok.

## Minőségi kapuk

- A forgalmi trend az utolsó 12 lezárt naptári hónap; a tárgyhavi részidőszak és az azóta érkezett kommunikáció külön frissességi blokk. A webes eseményablak a készítés napjától számított előző 12 hónap. Más időszakot csak felhasználói kérésre használj.
- A pénzösszegek pénzneme látszik. A nettó és bruttó értéket, darabot, palackegyenértéket és litert ne keverd.
- A trendleírás tartalmazza a teljes 12 havi forgalmat, rendelésdarabot, havi mintázatot, előző időszaki összevetést, termékmixet és a legutóbbi rendelést, amikor az adat elérhető. Részleges összehasonlításnál azonos hosszúságú időablakot használj.
- Minden tény kapjon forrásjelölést: `[CRM-n]` vagy `[WEB-n]`. Minden saját értelmezés kapjon `Következtetés` vagy `Javaslat` címkét.
- A webes aktualitás és akció külön eseménysor: dátum, esemény, Ostorosbor-relevancia, forrás. A „nem találtam” a keresés eredménye, nem a nemlétezés bizonyítéka.
- A fájlban nincs JavaScript, külső betűkészlet, külső CSS vagy későbbi adatbetöltés. Minden adat tényleges HTML-szövegként szerepel.
- Személyes adatból csak a tárgyaláshoz szükséges, jogosultsággal visszakapott üzleti elérhetőség kerüljön a belső briefbe. A HTML-t ne publikáld és ne küldd el az ügyfélnek.
- Hiányzó adatnál `Nincs adat` vagy `Nem volt elérhető` szerepeljen. Soha ne tölts ki mezőt becsléssel.
- A kész HTML-ben nem maradt `{{`; minden webes hivatkozás közvetlenül megnyitható; az öt vezetői sor valóban öt sor; az oldal mobilon olvasható és A4-re nyomtatható.

Ha a CRM-kapcsolat vagy az internetes keresés nem elérhető, készítsd el a rendelkezésre álló részt, az elején jól látható adatminőségi figyelmeztetéssel, és sorold fel pontosan, mi hiányzott. Írási/módosítási API-műveletet ez a skill nem igényel.
